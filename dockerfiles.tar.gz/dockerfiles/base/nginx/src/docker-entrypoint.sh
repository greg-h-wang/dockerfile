#!/bin/bash
set -e

CFG_PATH=${NGINX_HOME}

for CFG_FILE in `echo ${CFG_FILES} | sed 's/,/ /g'`
do
    REMOTE_CFG=/${CFG_LABEL}/${CFG_FILE}
    LOCAL_CFG=${CFG_PATH}/${CFG_FILE}
    echo "GET: REMOTE_ADDR=${CFG_ADDR} REMOTE_CFG=${REMOTE_CFG} LOCAL_CFG=${LOCAL_CFG}..."
    mkdir -p `dirname "${LOCAL_CFG}"`
    zkGet.py "${CFG_ADDR}" "${REMOTE_CFG}" "${LOCAL_CFG}"
    [ $? -ne 0 ] && echo "GET: ${REMOTE_CFG} failure!" 1>&2 && exit 1
    echo "GET: ${REMOTE_CFG} success!"
done

if [ "${1#-}" != "${1}" ]; then
    set -- nginx "${@}"
fi

exec "${@}" >> ${VOLUME_LOGS}/appConsole.log 2>&1
