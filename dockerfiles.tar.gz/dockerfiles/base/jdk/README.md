base/jdk
===

jdk安装在了/opt目录下，增添了加密扩展版本(jce)。
