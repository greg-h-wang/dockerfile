#! /bin/bash

elasticsearch ${@}
