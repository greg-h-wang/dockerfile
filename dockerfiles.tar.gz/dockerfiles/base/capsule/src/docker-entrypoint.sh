#!/bin/bash
set -e

if [ "${1}" == "jpda" ]; then
    CapsuleJvmArgs="-agentlib:jdwp=transport=dt_socket,address=${JPDA_ADDRESS},server=y,suspend=n ${CapsuleJvmArgs} "
    shift
fi

CFG_PATH=${CAPSULE_HOME}

for CFG_FILE in `echo ${CFG_FILES} | sed 's/,/ /g'`
do
    REMOTE_CFG=/${CFG_LABEL}/${CFG_FILE}
    LOCAL_CFG=${CFG_PATH}/${CFG_FILE}
    echo "GET: REMOTE_ADDR=${CFG_ADDR} REMOTE_CFG=${REMOTE_CFG} LOCAL_CFG=${LOCAL_CFG}..."
    mkdir -p `dirname "${LOCAL_CFG}"`
    zkGet.py "${CFG_ADDR}" "${REMOTE_CFG}" "${LOCAL_CFG}"
    [ $? -ne 0 ] && echo "GET: ${REMOTE_CFG} failure!" 1>&2 && exit 1
    echo "GET: ${REMOTE_CFG} success!"
done

[ -n "${JMX_IP}" ] && [ -n "${JMX_PORT}" ] && CapsuleJvmArgs="-Djava.rmi.server.hostname=${JMX_IP} -Dcom.sun.management.jmxremote.port=${JMX_PORT} -Dcom.sun.management.jmxremote.rmi.port=${JMX_PORT} -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false ${CapsuleJvmArgs} "

[ -r "${CAPSULE_HOME}/bin/setenv.sh" ] && . "${CAPSULE_HOME}/bin/setenv.sh"

if [ "${1#-}" != "${1}" ] || [ "${1##*.}" ==  "jar" ]; then
    set -- java -jar ${JAVA_OPTS} "-Dcapsule.jvm.args=${CapsuleJvmArgs}" ${@} ${CAPSULE_OPTS}
fi

export JAVA_OPTS CAPSULE_OPTS

logFile=${VOLUME_LOGS}/appConsole.log
oldLogFile=${VOLUME_LOGS}/appConsole.`date '+%Y-%m-%d.%H%M%S'`.log
[ -f ${logFile} ] && mv ${logFile} ${oldLogFile}

exec "${@}" >> ${logFile} 2>&1
