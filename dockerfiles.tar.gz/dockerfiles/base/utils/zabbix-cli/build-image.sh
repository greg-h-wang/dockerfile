#!/bin/bash

WORK_DIR=$(dirname ${0})
docker build -t zabbix-cli:latest ${WORK_DIR}

