#!/usr/bin/env python
from __future__ import print_function
from copy import deepcopy
try:
    from ConfigParser import ConfigParser
except ImportError:
    from configParser import ConfigParser
import argparse
import os

import requests


class ZabbixApi(object):
    headers = {"Content-Type": "application/json"}
    data = {
        "jsonrpc": "2.0",
        "method": "",
        "params": {},
        "id": 1,
    }

    def __init__(self):
        config = ConfigParser()
        config.read(os.environ["HOME"]+"/zabbix.conf")
        self.url = config.get("default", "url")
        self.user = config.get("default", "user")
        self.password = config.get("default", "password")
        if not self.data.get("auth", False):
            self.login()

    def post(self, post_data):
        response = requests.post(self.url, json=post_data, headers=self.headers)
        try:
            response_json = response.json()
        except Exception as e:
            print(e)
            print("response.text:" + response.text)
            response_json = {}
        if response_json.get("error"):
            raise RuntimeError("error request:{0}".format(str(response_json.get("error"))))
        return response_json

    def login(self):
        post_data = deepcopy(self.data)
        post_data["params"].update(user=self.user, password=self.password)
        post_data["method"] = "user.login"
        result = self.post(post_data)["result"]
        self.data["auth"] = result
        return result

    def get_item(self, item_name):
        post_data = deepcopy(self.data)
        post_data["method"] = "httptest.get"
        post_data["params"] = {
            "output": "extend",
            "search": {
                "name": item_name
            }
        }
        result = self.post(post_data)["result"]
        if len(result) == 0:
            raise RuntimeError("No such api: {0}".format(item_name))
        elif len(result) > 1:
            raise RuntimeError("Get too much result: {0}".format(str(result)))
        return result[0]

    def enable_item(self, item_name):
        item = self.get_item(item_name)
        if item["status"] == '0':
            print("Warning: Api monitor is already enabled, can not enable again!")
            return True
        post_data = deepcopy(self.data)
        post_data["method"] = "httptest.update"
        post_data["params"] = {"httptestid": item["httptestid"], "status": 0}
        result = self.post(post_data)["result"]
        if int(item["httptestid"]) in result["httptestids"]:
            return True
        return False

    def disable_item(self, item_name):
        item = self.get_item(item_name)
        if item["status"] == '1':
            print("Warning: Api monitor is already disabled, can not disable again!")
            return True
        post_data = deepcopy(self.data)
        post_data["method"] = "httptest.update"
        post_data["params"] = {"httptestid": item["httptestid"], "status": 1}
        result = self.post(post_data)["result"]
        if int(item["httptestid"]) in result["httptestids"]:
            return True
        return False


def make_arguments():
    parser = argparse.ArgumentParser(description='enable or disbale the Zabbix Web scenarios.')
    # parser.add_argument('--status', type=str, help='show api monitor status')
    subparsers = parser.add_subparsers(help='monitor actions')

    help_text = 'the container name like BOS_PROD_BOSPAY_10167842_11111'
    status = subparsers.add_parser('status', help='show api monitor status')
    status.add_argument(dest='status_container_name', action='store', help=help_text)
    enable = subparsers.add_parser('enable', help='enable api monitor')
    enable.add_argument(dest='enable_container_name', action='store', help=help_text)
    disable = subparsers.add_parser('disable', help='disable api monitor')
    disable.add_argument(dest='disable_container_name', action='store', help=help_text)

    args = parser.parse_args()

    z = ZabbixApi()
    if getattr(args, 'status_container_name', False):
        item = z.get_item(getattr(args, 'status_container_name'))
        if item['status'] == '1':
            print('disabled')
        elif item['status'] == '0':
            print('enabled')
        else:
            print('unknown')
    if getattr(args, 'enable_container_name', False):
        z.enable_item(getattr(args, 'enable_container_name'))
    if getattr(args, 'disable_container_name', False):
        z.disable_item(getattr(args, 'disable_container_name'))


if __name__ == '__main__':
    make_arguments()

