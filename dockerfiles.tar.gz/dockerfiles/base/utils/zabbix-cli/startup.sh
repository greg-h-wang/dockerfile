#!/bin/bash

CWD=$(dirname ${0})
if [ "x$CWD" == "x." ]; then
    CWD=$(pwd)
fi

#    -it --entrypoint bash \
docker run --rm -it \
    -e CFG_ADDR=:2181 \
    -e CFG_FILES=zabbix.conf \
    -e CFG_LABEL=DIANRONG_DEV_ZABBIX \
    zabbix-cli status ci-dev-httpchecker

