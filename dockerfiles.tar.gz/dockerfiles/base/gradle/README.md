base/gradle
===

使用时挂载/buildspace和/VolumeDump目录，/VolumeDump目录link到了本地缓存目录。

示例：
````bash
docker run --rm -v CodePath:/buildspace -v CachePath:/VolumeDump base/gradle:version gradle options
````
