base/tomcat
===

tomcat安装在了/opt目录下，ojdbc版本的用于支持oracle连接，redis版本用于支持redis连接，kazoo版本的用于支持从zookeeper取配置。

添加了三个可选变量：AppId、AppLabel、AppAddress

使用kazoo版本的镜像、依赖三个变量：ZookeeperCluster、AppCfgs、InstanceId，如果InstanceId为空，InstanceId＝AppLabel，在AppCfgs不为空的情况下，InstanceId和AppLabel不能同时为空。

/VolumeLogs目录link到了${CATALINA_HOME}/logs

示例：
````bash
docker run -d -p 8080:8080 -v ContainerLogs:/VolumeLogs base/tomcat:version run
````
