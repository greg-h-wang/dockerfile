#!/bin/bash
set -e

CFG_PATH=${CATALINA_HOME}

for CFG_FILE in `echo ${CFG_FILES} | sed 's/,/ /g'`
do
    REMOTE_CFG=/${CFG_LABEL}/${CFG_FILE}
    LOCAL_CFG=${CFG_PATH}/${CFG_FILE}
    echo "GET: REMOTE_ADDR=${CFG_ADDR} REMOTE_CFG=${REMOTE_CFG} LOCAL_CFG=${LOCAL_CFG}..."
    mkdir -p `dirname "${LOCAL_CFG}"`
    zkGet.py "${CFG_ADDR}" "${REMOTE_CFG}" "${LOCAL_CFG}"
    [ $? -ne 0 ] && echo "GET: ${REMOTE_CFG} failure!" 1>&2 && exit 1
    echo "GET: ${REMOTE_CFG} success!"
done

[ -n "${JMX_IP}" ] && [ -n "${JMX_PORT}" ] && export JAVA_OPTS="${JAVA_OPTS} -Djava.rmi.server.hostname=${JMX_IP} -Dcom.sun.management.jmxremote.port=${JMX_PORT} -Dcom.sun.management.jmxremote.rmi.port=${JMX_PORT} -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false"

case ${1} in
    debug | jpda | run | start | configtest | stop | version)
        set -- catalina.sh "${@}"
        ;;
esac

export JAVA_OPTS CATALINA_OPTS

logFile=${VOLUME_LOGS}/appConsole.log
oldLogFile=${VOLUME_LOGS}/appConsole.`date '+%Y-%m-%d.%H%M%S'`.log
[ -f ${logFile} ] && mv ${logFile} ${oldLogFile}

exec "${@}" >> ${logFile} 2>&1
