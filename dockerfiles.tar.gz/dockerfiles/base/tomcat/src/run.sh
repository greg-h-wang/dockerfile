#!/bin/bash

[ -z "${AppId}" ] && echo '${AppId} is nil.' 1>&2 && exit 1
[ -z "${AppLogs}" ] && AppLogs="${VolumeLogs}/${AppId}"
[ -z "${AppDump}" ] && AppDump="${VolumeDump}/${AppId}"

AppLabel=${AppId%_*_*}
AppIp=${AppAddress%:*}
AppPort=${AppAddress#*:}

for AppCfg in `echo ${AppCfgs} | sed 's/,/ /g'`
do
  echo "zkGet.py ${ZookeeperCluster} /instances/${AppLabel}/${AppCfg} ..."
  zkGet.py "${ZookeeperCluster}" "/instances/${AppLabel}/${AppCfg}" >"${AppHome}/${AppCfg}"
  [ $? -ne 0 ] && echo "zkGet.py ${ZookeeperCluster} /instances/${AppLabel}/${AppCfg} failure!" 1>&2 && exit 1
  echo "zkGet.py ${ZookeeperCluster} /instances/${AppLabel}/${AppCfg} success!"
done

[ -r "${AppHome}/bin/setenv.sh" ] && . "${AppHome}/bin/setenv.sh"
[ -z "${Jmx}" ] && [ -n "${JmxPort}" ] && Jmx="-Djava.rmi.server.hostname=${AppIp} -Dcom.sun.management.jmxremote.port=${JmxPort} -Dcom.sun.management.jmxremote.rmi.port=${JmxPort} -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false"
[ -z "${Jpda}" ] && [ -n "${JpdaAddress}" ] && Jpda="-agentlib:jdwp=transport=dt_socket,address=${JpdaAddress},server=y,suspend=n"

mkdir -p "${AppLogs}" "${AppDump}"

export AppLogs AppDump Jmx Jpda
rm -rf ${AppHome}/logs && ln -s ${AppLogs} ${AppHome}/logs

logFile=${AppLogs}/appConsole.log
oldLogFile=${AppLogs}/appConsole.`date '+%Y-%m-%d.%H%M%S'`.log
[ -f ${logFile} ] && mv ${logFile} ${oldLogFile}

eval exec java -DAppLogs=${AppLogs} -DAppDump=${AppDump} ${Jmx} ${Jpda} ${EnvOpts} ${JavaOpts} ${@} \
               -Djava.util.logging.config.file=${AppHome}/conf/logging.properties \
               -Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager \
               -Dcatalina.logs=${AppLogs} \
               -Dcatalina.base=${AppHome} \
               -Dcatalina.home=${AppHome} \
               -Djava.io.tmpdir=${AppHome}/temp \
               -Djava.endorsed.dirs=${AppHome}/endorsed \
               -classpath ${AppHome}/bin/bootstrap.jar:${AppHome}/bin/tomcat-juli.jar \
               org.apache.catalina.startup.Bootstrap start >> ${logFile} 2>&1
