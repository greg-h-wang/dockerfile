#!/bin/bash

echo > err.log
cd `dirname ${BASH_SOURCE}`
suffix="2257b4561a43e400e437b662529255e3"
unset DOCKER_REGISTRY
[ -n "${1}" ] && DOCKER_REGISTRY="${1%%/*}/"
NOCACHE="${2:-false}"
FORCE_PUSH="${3:-false}"
DRY_RUN="${4:-false}"
resources=`pwd`/resources
DOCKER_BUILD_LIST=`grep -v '^ *#' build.list`

docker build -t centos:init -f library/centos/centos=init.df library/centos
docker build -t simplehttpserver:init -f library/simplehttpserver/simplehttpserver=init.df library/simplehttpserver

docker stop simplehttpserver-${suffix} && docker rm simplehttpserver-${suffix} || echo
docker run -d --name simplehttpserver-${suffix} -v ${resources}:/mnt simplehttpserver:init
fsIp=`docker inspect -f '{{.NetworkSettings.IPAddress}}' simplehttpserver-${suffix}`

for LINE in ${DOCKER_BUILD_LIST}
do
    FROM_IMAGE=`echo ${LINE} | awk -F',' '{print $1}'`
    TO_IMAGE=`echo ${LINE} | awk -F',' '{print $2}'`
    DOCKERFILE_FILE=`echo ${LINE} | awk -F',' '{print $3}'`
    DOCKERFILE_PATH=${DOCKERFILE_FILE%/*}

    if [ "x${FORCE_PUSH}" == "xfalse" ]; then
        [ -n "${DOCKER_REGISTRY}" ] && docker pull ${DOCKER_REGISTRY}${TO_IMAGE} && continue || echo
    fi

    #
    # Dockerfile 中多个 FROM 指令的支持
    # ==================================
    # 如果 Dockerfile 中包含 '#__FROM__' 关键字（# 在行首，后面可包含多个空白符），
    # 则保留其中的 FROM 指令，并在关键字后面插入新的 FROM 指令
    # 否则，删除其中的 FROM 指令，并在第一行插入新的 FROM 指令
    #
    grep -qE "^#\s*__FROM__" ${DOCKERFILE_FILE}
    __ret=$?
    if [ ${__ret} -eq 0 ]; then
        # Dockerfile 中有关键字，保留 FROM 指令，在关键字后插入新的 FROM 指令
        __IS_KEEP_FROM_INSTRUCTION="true"
    elif [ ${__ret} -eq 1 ]; then
        # Dockerfile 中没有关键字，按照之前的处理逻辑删除 FROM 指令，然后在第一行插入新的 FROM 指令
        __IS_KEEP_FROM_INSTRUCTION="false"
    else
        # 文件不存在等（错误提示由 grep 输出）
        exit ${__ret}
    fi

    if [ "x${__IS_KEEP_FROM_INSTRUCTION}" == "xfalse" ]; then
        # 从 Dockerfile 中删除 FROM 指令
        sed -i '/^FROM/d' ${DOCKERFILE_FILE}
    fi

    if [ 'scratch' != "${FROM_IMAGE}" ]
    then
        if [ "x${__IS_KEEP_FROM_INSTRUCTION}" == "xfalse" ]; then
            # 在第一行插入 FROM 指令
            sed -i "1iARG SIMPLE_HTTP_SERVER" ${DOCKERFILE_FILE}
            sed -i "1iFROM ${DOCKER_REGISTRY}${FROM_IMAGE}" ${DOCKERFILE_FILE}
        else
            # 在 '#__FROM__' 关键字后插入 FROM 指令
            sed -i "/^#\s*__FROM__/aARG SIMPLE_HTTP_SERVER" ${DOCKERFILE_FILE}
            sed -i "/^#\s*__FROM__/aFROM ${DOCKER_REGISTRY}${FROM_IMAGE}" ${DOCKERFILE_FILE}
        fi

        docker build -t ${DOCKER_REGISTRY}${TO_IMAGE} --no-cache=${NOCACHE} --build-arg SIMPLE_HTTP_SERVER=${fsIp} -f ${DOCKERFILE_FILE} ${DOCKERFILE_PATH} || \
        echo "docker build -t ${DOCKER_REGISTRY}${TO_IMAGE} --no-cache=${NOCACHE} --build-arg SIMPLE_HTTP_SERVER=${fsIp} -f ${DOCKERFILE_FILE} ${DOCKERFILE_PATH} FAILURE" >> err.log
    else
        sed -i "1iFROM ${FROM_IMAGE}" ${DOCKERFILE_FILE}
        docker build -t ${DOCKER_REGISTRY}${TO_IMAGE} --no-cache=${NOCACHE} -f ${DOCKERFILE_FILE} ${DOCKERFILE_PATH} || \
        echo "docker build -t ${DOCKER_REGISTRY}${TO_IMAGE} --no-cache=${NOCACHE} -f ${DOCKERFILE_FILE} ${DOCKERFILE_PATH} FAILURE" >> err.log
    fi
    if [ "x${__IS_KEEP_FROM_INSTRUCTION}" == "xfalse" ]; then
        sed -i '/^FROM/d' ${DOCKERFILE_FILE}
        sed -i '/^ARG SIMPLE_HTTP_SERVER/d' ${DOCKERFILE_FILE}
    else
        sed -i '/^#\s*__FROM__/{n;d}' ${DOCKERFILE_FILE}
        sed -i '/^#\s*__FROM__/{n;d}' ${DOCKERFILE_FILE}
    fi

    if [ "x${DRY_RUN}" != "xtrue" ]; then
        [ -n "${DOCKER_REGISTRY}" ] && docker push ${DOCKER_REGISTRY}${TO_IMAGE}
    fi
done

docker stop simplehttpserver-${suffix} && docker rm simplehttpserver-${suffix} || echo

