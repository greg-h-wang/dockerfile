#!/bin/bash
set -e

[ -z "${ZOOCFGDIR}" ] && export ZOOCFGDIR=${ZOOKEEPER_HOME}/conf

cat > ${ZOOCFGDIR}/zoo.cfg << EOF
clientPort=2181
dataDir=${ZOOKEEPER_HOME}/dump
dataLogDir=${ZOOKEEPER_HOME}/logs
tickTime=${ZOO_TICK_TIME}
initLimit=${ZOO_INIT_LIMIT}
syncLimit=${ZOO_SYNC_LIMIT}
maxClientCnxns=${ZOO_CLIENT_CNXNS}
EOF

for server in ${ZOO_SERVERS}; do echo "${server}" >> ${ZOOCFGDIR}/zoo.cfg; done

[ ! -f "${ZOOKEEPER_HOME}/dump/myid" ] && echo "${ZOO_MY_ID:-1}" > ${ZOOKEEPER_HOME}/dump/myid

echo 'export JVMFLAGS="$JAVA_OPTS $JVMFLAGS"' >  $ZOOCFGDIR/java.env

case ${1} in
    start | start-foreground | stop | restart | status | upgrade| print-cmd)
        set -- zkServer.sh "${@}"
        ;;
esac

logFile=${VOLUME_LOGS}/appConsole.log
oldLogFile=${VOLUME_LOGS}/appConsole.`date '+%Y-%m-%d.%H%M%S'`.log
[ -f ${logFile} ] && mv ${logFile} ${oldLogFile}

exec "${@}" >> ${logFile} 2>&1
