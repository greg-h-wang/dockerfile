#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from kazoo.client import KazooClient
zkCli = KazooClient(hosts='%s' % sys.argv[1], timeout=10, read_only=True)
zkCli.start()
f = open(sys.argv[3], 'wb')
f.write(zkCli.get(path='%s' % sys.argv[2])[0])
f.close()
zkCli.stop()
